export interface Permissions {
    [resource: string]: string[];
  }
  