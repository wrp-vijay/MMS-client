import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-ABFNOLXB.js";
import "./chunk-CIKKADTV.js";
import "./chunk-UUENCTTU.js";
import "./chunk-5ZQCAXUB.js";
import "./chunk-44W7MHPD.js";
import "./chunk-6WT4BXUU.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-L7T36SQB.js";
import "./chunk-ZCAARMLP.js";
import "./chunk-6VP3O3YG.js";
import "./chunk-EQDNXYDC.js";
import "./chunk-LDODSSGN.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
